import fs from "fs";

export default class Storage {
  constructor(filename = "data.json") {
    this.filename = filename;
    if (!fs.existsSync(this.filename)) fs.writeFileSync(this.filename, JSON.stringify({ users: [], tasks: [] }));
  }

  read() {
    const data = fs.readFileSync(this.filename, "utf-8");
    return JSON.parse(data);
  }

  write(data) {
    fs.writeFileSync(this.filename, JSON.stringify(data, null, 2));
  }
}
