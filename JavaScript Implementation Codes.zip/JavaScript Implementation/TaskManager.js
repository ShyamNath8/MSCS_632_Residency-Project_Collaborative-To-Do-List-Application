export default class TaskManager {
  constructor(storage) {
    this.storage = storage;
    const data = this.storage.read();
    this.users = data.users;
    this.tasks = data.tasks;
    this.nextUserId = this.users.length ? Math.max(...this.users.map(u => u.id)) + 1 : 1;
    this.nextTaskId = this.tasks.length ? Math.max(...this.tasks.map(t => t.id)) + 1 : 1;
  }

  save() {
    this.storage.write({ users: this.users, tasks: this.tasks });
  }

  createUser(name) {
    const user = { id: this.nextUserId++, name };
    this.users.push(user);
    this.save();
    return user;
  }

  createTask(title, description = "", category = "General", priority = "Normal") {
    const task = { id: this.nextTaskId++, title, description, category, priority, completed: false, assignedTo: null };
    this.tasks.push(task);
    this.save();
    return task;
  }

  listAll() {
    return this.tasks;
  }

  listByUser(userId) {
    return this.tasks.filter(t => t.assignedTo === userId);
  }

  listByCategory(category) {
    return this.tasks.filter(t => t.category === category);
  }

  assignTask(taskId, userId) {
    const task = this.tasks.find(t => t.id === taskId);
    if (!task) return false;
    task.assignedTo = userId;
    this.save();
    return true;
  }

  markCompleted(taskId) {
    const task = this.tasks.find(t => t.id === taskId);
    if (!task) return false;
    task.completed = true;
    this.save();
    return true;
  }

  findUserByName(name) {
    return this.users.find(u => u.name === name);
  }
}
