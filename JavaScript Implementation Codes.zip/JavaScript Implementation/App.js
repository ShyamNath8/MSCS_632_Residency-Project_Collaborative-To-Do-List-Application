import readlineSync from "readline-sync";
import TaskManager from "./TaskManager.js";
import Storage from "./storage.js";

const storage = new Storage();
const tm = new TaskManager(storage);

printHelp();

while (true) {
  const line = readlineSync.question("> ").trim();
  if (!line) continue;

  const [cmd, ...restParts] = line.split(" ");
  const rest = restParts.join(" ");

  try {
    switch (cmd.toLowerCase()) {
      case "help": printHelp(); break;
      case "create-user":
        const u = tm.createUser(rest);
        console.log("Created", u);
        break;
      case "create-task": {
        const p = rest.split("|");
        const t = tm.createTask(
          p[0].trim(),
          p[1]?.trim() || "",
          p[2]?.trim() || "General",
          p[3]?.trim() || "Normal"
        );
        console.log("Created", t);
        break;
      }
      case "list":
        tm.listAll().forEach(t => console.log(t));
        break;
      case "list-user": {
        const user = tm.findUserByName(rest);
        if (user) tm.listByUser(user.id).forEach(t => console.log(t));
        else console.log("User not found");
        break;
      }
      case "list-category":
        tm.listByCategory(rest).forEach(t => console.log(t));
        break;
      case "assign": {
        const [taskId, username] = rest.split(" ");
        const user = tm.findUserByName(username);
        if (!user) console.log("User not found");
        else if (tm.assignTask(Number(taskId), user.id)) console.log("Assigned");
        else console.log("Task not found");
        break;
      }
      case "complete": {
        if (tm.markCompleted(Number(rest))) console.log("Marked completed");
        else console.log("Task not found");
        break;
      }
      case "exit": console.log("Bye"); process.exit(0);
      default: console.log("Unknown command. Type help.");
    }
  } catch (err) {
    console.log("Error:", err.message);
  }
}

function printHelp() {
  console.log("Commands:");
  console.log(" create-user <username>");
  console.log(" create-task <title>|<description>|<category>|<priority>");
  console.log(" list");
  console.log(" list-user <username>");
  console.log(" list-category <category>");
  console.log(" assign <taskId> <username>");
  console.log(" complete <taskId>");
  console.log(" help");
  console.log(" exit");
}
