package app;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

public class TaskManager {
    private final StorageManager storage;
    private final List<User> users;
    private final List<Task> tasks;
    private final AtomicInteger taskIdCounter = new AtomicInteger(100);
    private final AtomicInteger userIdCounter = new AtomicInteger(1);

    public TaskManager(StorageManager storage) {
        this.storage = storage;
        this.users = new ArrayList<>(storage.loadUsers());
        this.tasks = new ArrayList<>(storage.loadTasks());
        // init counters
        users.forEach(u -> userIdCounter.set(Math.max(userIdCounter.get(), u.getId()+1)));
        tasks.forEach(t -> taskIdCounter.set(Math.max(taskIdCounter.get(), t.getId()+1)));
    }

    // users
    public User createUser(String username) {
        User u = new User(userIdCounter.getAndIncrement(), username);
        users.add(u); persist();
        return u;
    }

    public Optional<User> findUserByName(String username) {
        return users.stream().filter(u -> u.getUsername().equals(username)).findFirst();
    }

    // tasks
    public Task createTask(String title, String desc, String category, String priority) {
        Task t = new Task(taskIdCounter.getAndIncrement(), title, desc, category, priority);
        tasks.add(t); persist();
        return t;
    }

    public List<Task> listAll() { return Collections.unmodifiableList(tasks); }

    public List<Task> listByUser(int userId) {
        return tasks.stream().filter(t -> t.getAssignedTo().contains(userId)).collect(Collectors.toList());
    }

    public List<Task> listByCategory(String category) {
        return tasks.stream().filter(t -> t.getCategory().equalsIgnoreCase(category)).collect(Collectors.toList());
    }

    public boolean assignTask(int taskId, int userId) {
        Optional<Task> ot = tasks.stream().filter(t -> t.getId() == taskId).findFirst();
        if (ot.isEmpty()) return false;
        ot.get().assignTo(userId);
        persist();
        return true;
    }

    public boolean markCompleted(int taskId) {
        Optional<Task> ot = tasks.stream().filter(t -> t.getId() == taskId).findFirst();
        if (ot.isEmpty()) return false;
        ot.get().setStatus(Task.Status.COMPLETED);
        persist();
        return true;
    }

    private void persist() {
        storage.saveAll(users, tasks);
    }
}
