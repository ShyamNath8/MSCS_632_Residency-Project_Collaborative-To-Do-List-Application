package app;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

public class Task {
    public enum Status { PENDING, IN_PROGRESS, COMPLETED }

    private int id;
    private String title;
    private String description;
    private String category;
    private String priority;
    private Status status;
    private List<Integer> assignedTo; // user ids
    private String createdAt;
    private String updatedAt;

    public Task() {}

    public Task(int id, String title, String desc, String category, String priority) {
        this.id = id; this.title = title; this.description = desc;
        this.category = category; this.priority = priority;
        this.status = Status.PENDING;
        this.assignedTo = new ArrayList<>();
        this.createdAt = Instant.now().toString();
        this.updatedAt = this.createdAt;
    }

    // getters / setters
    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getCategory() { return category; }
    public String getPriority() { return priority; }
    public Status getStatus() { return status; }
    public List<Integer> getAssignedTo() { return assignedTo; }
    public void setStatus(Status s) { this.status = s; this.updatedAt = Instant.now().toString(); }
    public void assignTo(int userId) { if (!assignedTo.contains(userId)) assignedTo.add(userId); this.updatedAt = Instant.now().toString(); }

    @Override
    public String toString() {
        return String.format("Task{id=%d, title='%s', category='%s', priority='%s', status=%s, assigned=%s}",
                id, title, category, priority, status, assignedTo.toString());
    }
}
