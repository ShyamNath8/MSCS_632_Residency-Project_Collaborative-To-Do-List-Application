package app;

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        StorageManager storage = new StorageManager();
        TaskManager tm = new TaskManager(storage);
        Scanner sc = new Scanner(System.in);
        printHelp();
        while (true) {
            System.out.print("> ");
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+", 2);
            String cmd = parts[0].toLowerCase();
            String rest = parts.length>1 ? parts[1] : "";
            try {
                switch (cmd) {
                    case "help": printHelp(); break;
                    case "create-user":
                        User u = tm.createUser(rest);
                        System.out.println("Created " + u);
                        break;
                    case "create-task": {
                        String[] p = rest.split("\\|");
                        // expected: title|description|category|priority
                        Task t = tm.createTask(p[0].trim(), p.length>1 ? p[1].trim() : "", p.length>2 ? p[2].trim() : "General", p.length>3 ? p[3].trim() : "Normal");
                        System.out.println("Created " + t);
                        break;
                    }
                    case "list":
                        List<Task> all = tm.listAll();
                        all.forEach(System.out::println);
                        break;
                    case "list-user":
                        Optional<User> ou = tm.findUserByName(rest);
                        if (ou.isPresent()) { tm.listByUser(ou.get().getId()).forEach(System.out::println); } else System.out.println("User not found");
                        break;
                    case "list-category":
                        tm.listByCategory(rest).forEach(System.out::println);
                        break;
                    case "assign": {
                        String[] partsAssign = rest.split("\\s+");
                        int taskId = Integer.parseInt(partsAssign[0]);
                        String username = partsAssign[1];
                        Optional<User> uop = tm.findUserByName(username);
                        if (uop.isEmpty()) System.out.println("User not found");
                        else if (tm.assignTask(taskId, uop.get().getId())) System.out.println("Assigned");
                        else System.out.println("Task not found");
                        break;
                    }
                    case "complete": {
                        int id = Integer.parseInt(rest);
                        if (tm.markCompleted(id)) System.out.println("Marked completed");
                        else System.out.println("Task not found");
                        break;
                    }
                    case "exit":
                        System.out.println("Bye"); sc.close(); return;
                    default:
                        System.out.println("Unknown command. Type help.");
                }
            } catch (Exception ex) {
                System.out.println("Error: " + ex.getMessage());
            }
        }
    }

    private static void printHelp() {
        System.out.println("Commands:");
        System.out.println(" create-user <username>");
        System.out.println(" create-task <title>|<description>|<category>|<priority>");
        System.out.println(" list");
        System.out.println(" list-user <username>");
        System.out.println(" list-category <category>");
        System.out.println(" assign <taskId> <username>");
        System.out.println(" complete <taskId>");
        System.out.println(" help");
        System.out.println(" exit");
    }
}
