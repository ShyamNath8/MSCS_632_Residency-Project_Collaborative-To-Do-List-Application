package app;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.locks.*;

public class StorageManager {
    private final Path usersFile = Paths.get("users.json");
    private final Path tasksFile = Paths.get("tasks.json");
    private final ReadWriteLock rwLock = new ReentrantReadWriteLock();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public List<User> loadUsers() {
        rwLock.readLock().lock();
        try {
            if (!Files.exists(usersFile)) return new ArrayList<>();
            Reader r = Files.newBufferedReader(usersFile);
            Type t = new TypeToken<List<User>>(){}.getType();
            List<User> list = gson.fromJson(r, t);
            r.close();
            return list == null ? new ArrayList<>() : list;
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        } finally {
            rwLock.readLock().unlock();
        }
    }

    public List<Task> loadTasks() {
        rwLock.readLock().lock();
        try {
            if (!Files.exists(tasksFile)) return new ArrayList<>();
            Reader r = Files.newBufferedReader(tasksFile);
            Type t = new TypeToken<List<Task>>(){}.getType();
            List<Task> list = gson.fromJson(r, t);
            r.close();
            return list == null ? new ArrayList<>() : list;
        } catch (IOException e) {
            e.printStackTrace();
            return new ArrayList<>();
        } finally {
            rwLock.readLock().unlock();
        }
    }

    // atomic save with write lock
    public void saveAll(List<User> users, List<Task> tasks) {
        rwLock.writeLock().lock();
        try {
            Files.writeString(usersFile, gson.toJson(users), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            Files.writeString(tasksFile, gson.toJson(tasks), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            rwLock.writeLock().unlock();
        }
    }
}
